// Drivers/BSP/Src/bsp_adc.c
#include "bsp_adc.h"
#include "stm32f1xx_hal.h"

ADC_HandleTypeDef hadc1;

void BSP_ADC_Init(void) {
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  HAL_ADC_Init(&hadc1);

  sConfig.Channel = ADC_CHANNEL_0;  // 对应PA0
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_55CYCLES_5;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
}

uint16_t BSP_ADC_ReadValue(void) {
  HAL_ADC_Start(&hadc1);
  HAL_ADC_PollForConversion(&hadc1, 100);  // 超时100ms
  return HAL_ADC_GetValue(&hadc1);
}
