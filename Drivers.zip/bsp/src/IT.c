// Drivers/BSP/Src/bsp_uart.c
#include "bsp_uart.h"
#include "stm32f1xx_hal_uart.h"

UART_HandleTypeDef huart1;
uint8_t rx_buffer[128];

void BSP_UART_Init(uint32_t baudrate) {
  huart1.Instance = USART1;
  huart1.Init.BaudRate = baudrate;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  HAL_UART_Init(&huart1);

  // 启用接收中断
  HAL_UART_Receive_IT(&huart1, rx_buffer, 1);  // 单字节接收
}

// 中断回调函数
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
  if (huart->Instance == USART1) {
    // 处理接收到的数据（rx_buffer[0]）
    // 重新启用接收
    HAL_UART_Receive_IT(&huart1, rx_buffer, 1);
  }
}
